package Suporte;

public class Tabelas {
    
    String html = "";
    
    public String Tamanhos() {
        
        //HOMENS:
        html =  "<br><b>-------------------------------------------------------------------------------------------"
                + "--------------------------------------------------------------------</b><br>" +
                "<h3 style=\"font-size:25px;\">GUIA DE TAMANHOS</h3>" +
                "<h3 style=\"font-size:22px; color: skyblue; margin-bottom:-15px;\">HOMEM</h3>" +
                "  <h4 style=\"font-size:17px;\">PARTE DE CIMA: Camisetas, regatas, camisas, jaquetas com capuz, agasalho com capuz, casacos...</h4>\n" +
                "  <div style=\"font-size:16px; margin-top:-15px\">\n" +
                "    <table border=\"1\" cellpadding=\"5\" width=\"900\" cellspacing=\"1\">\n" +
                "      <thead>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Medida do peito (cm): </th>\n" +
                "          <td>84-87</td>\n" +
                "          <td>88-91</td>\n" +
                "          <td>92-95</td>\n" +
                "          <td>96-103</td>\n" +
                "          <td>104-113</td>\n" +
                "          <td>114-123</td>\n" +
                "          <td>124-135</td>\n" +
                "          <td>136-146</td>\n" +
                "          <td>147-159</td>\n" +
                "        </tr>\n" +
                "      </thead>\n" +
                "      <tbody>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [EU]</th>\n" +
                "          <td>XS</td>\n" +
                "          <td>S</td>\n" +
                "          <td>M</td>\n" +
                "          <td>L</td>\n" +
                "          <td>XL</td>\n" +
                "          <td>2XL</td>\n" +
                "          <td>3XL</td>\n" +
                "          <td>4XL</td>\n" +
                "          <td>5XL</td>\n" +
                "        </tr>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [BR]</th>\n" +
                "          <td>PP</td>\n" +
                "          <td>P</td>\n" +
                "          <td>M</td>\n" +
                "          <td>G</td>\n" +
                "          <td>GG</td>\n" +
                "          <td>3G</td>\n" +
                "          <td>4G</td>\n" +
                "          <td>5G</td>\n" +
                "          <td>6G</td>\n" +
                "        </tr>\n" +
                "      </tbody>\n" +
                "    </table>\n" +
                "  </div>\n" +
                "  <h4 style=\"font-size:17px;\">PARTE DE BAIXO: Shorts, calças, roupa de baixo, roupa de banho...</h4>\n" +
                "  <div style=\"font-size:16px; margin-top:-15px;\">\n" +
                "    <table border=\"1\" cellpadding=\"5\" width=\"840\" cellspacing=\"1\">\n" +
                "      <thead>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Medida da cintura (cm): </th>\n" +
                "          <td>70-73</td>\n" +
                "          <td>74-77</td>\n" +
                "          <td>78-81</td>\n" +
                "          <td>82-89</td>\n" +
                "          <td>90-100</td>\n" +
                "          <td>101-111</td>\n" +
                "          <td>112-123</td>\n" +
                "          <td>124-135</td>\n" +
                "          <td>136-147</td>\n" +
                "        </tr>\n" +
                "      </thead>\n" +
                "      <tbody>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [EU]</th>\n" +
                "          <td>XS</td>\n" +
                "          <td>S</td>\n" +
                "          <td>M</td>\n" +
                "          <td>L</td>\n" +
                "          <td>XL</td>\n" +
                "          <td>2XL</td>\n" +
                "          <td>3XL</td>\n" +
                "          <td>4XL</td>\n" +
                "          <td>5XL</td>\n" +
                "        </tr>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [BR]</th>\n" +
                "          <td>PP</td>\n" +
                "          <td>P</td>\n" +
                "          <td>M</td>\n" +
                "          <td>G</td>\n" +
                "          <td>GG</td>\n" +
                "          <td>3G</td>\n" +
                "          <td>4G</td>\n" +
                "          <td>5G</td>\n" +
                "          <td>6G</td>\n" +
                "        </tr>\n" +
                "      </tbody>\n" +
                "    </table>\n" +
                "  </div>\n" +
                "</section>" +
                
//////////////////////////////////MULHERES://///////////////////////////////////

                
                "<section>" +
                "<h3 style=\"font-size:22px; color: pink; margin-top: 35px; margin-bottom:-15px;\">MULHER</h3>\n" +
                "  <h4 style=\"font-size:17px;\">PARTE DE CIMA: Camisetas, regatas, camisas, jaquetas com capuz, agasalho com capuz, casacos, roupa de banho...</h4>\n" +
                "  <div style=\"font-size:16px; margin-top:-15px\">\n" +
                "    <table border=\"1\" cellpadding=\"5\" width=\"980\" cellspacing=\"1\"\n" +
                "      <thead>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Medida do peito (cm): </th>\n" +
                "          <td>80-83</td>\n" +
                "          <td>84-87</td>\n" +
                "          <td>88-91</td>\n" +
                "          <td>92-95</td>\n" +
                "          <td>96-103</td>\n" +
                "          <td>104-113</td>\n" +
                "          <td>114-123</td>\n" +
                "          <td>124-135</td>\n" +
                "          <td>136-146</td>\n" +
                "          <td>147-159</td>\n" +
                "        </tr>\n" +
                "      </thead>\n" +
                "      <tbody>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [EU]</th>\n" +
                "          <td>2XS</td>\n" +
                "          <td>XS</td>\n" +
                "          <td>S</td>\n" +
                "          <td>M</td>\n" +
                "          <td>L</td>\n" +
                "          <td>XL</td>\n" +
                "          <td>2XL</td>\n" +
                "          <td>3XL</td>\n" +
                "          <td>4XL</td>\n" +
                "          <td>5XL</td>\n" +
                "        </tr>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [BR]</th>\n" +
                "          <td>3P</td>\n" +
                "          <td>PP</td>\n" +
                "          <td>P</td>\n" +
                "          <td>M</td>\n" +
                "          <td>G</td>\n" +
                "          <td>GG</td>\n" +
                "          <td>3G</td>\n" +
                "          <td>4G</td>\n" +
                "          <td>5G</td>\n" +
                "          <td>6G</td>\n" +
                "        </tr>\n" +
                "      </tbody>\n" +
                "    </table>\n" +
                "  </div>\n" +
                "  <h4 style=\"font-size:17px;\">PARTE DE BAIXO: Shorts, calças, roupa de baixo...</h4>\n" +
                "  <div style=\"font-size:16px; margin-top:-15px\">\n" +
                "    <table border=\"1\" cellpadding=\"5\" width=\"900\" cellspacing=\"1\">\n" +
                "      <thead>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Medida da cintura (cm): </th>\n" +
                "          <td>58-62</td>\n" +
                "          <td>63-65</td>\n" +
                "          <td>66-69</td>\n" +
                "          <td>70-73</td>\n" +
                "          <td>74-84</td>\n" +
                "          <td>85-96</td>\n" +
                "          <td>97-108</td>\n" +
                "          <td>109-120</td>\n" +
                "          <td>121-132</td>\n" +
                "          <td>133-145</td>\n" +
                "        </tr>\n" +
                "      </thead>\n" +
                "      <tbody>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [EU]</th>\n" +
                "          <td>2XS</td>\n" +
                "          <td>XS</td>\n" +
                "          <td>S</td>\n" +
                "          <td>M</td>\n" +
                "          <td>L</td>\n" +
                "          <td>XL</td>\n" +
                "          <td>2XL</td>\n" +
                "          <td>3XL</td>\n" +
                "          <td>4XL</td>\n" +
                "          <td>5XL</td>\n" +
                "        </tr>\n" +
                "        <tr>\n" +
                "          <th align = \"left\">Tamanhos [BR]</th>\n" +
                "          <td>3P</td>\n" +
                "          <td>PP</td>\n" +
                "          <td>P</td>\n" +
                "          <td>M</td>\n" +
                "          <td>G</td>\n" +
                "          <td>GG</td>\n" +
                "          <td>3G</td>\n" +
                "          <td>4G</td>\n" +
                "          <td>5G</td>\n" +
                "          <td>6G</td>\n" +
                "        </tr>\n" +
                "      </tbody>\n" +
                "    </table>\n" +
                "  </div>\n";          
        
        return html;
    }
}

