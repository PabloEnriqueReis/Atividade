# AV1_OBJ
Atividade da AV1 da disciplina "Aplicações Orientadas a Objetos

Professor Daniel, fiz o tratamento de erros conforme foi passado na aula, mas continua sendo tratado automaticamente pelo GlassFish no meu NetBeans. 
Fiz tanto pelo Try/Catch quanto pela especificação da ErrorPage, mas ambos não estão funcionando. 

Acredito que deva funcionar, mas caso esteja incorreto, poderia me informar o erro por favor? 

Obrigado.
